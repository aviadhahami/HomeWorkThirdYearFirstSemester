package enums;


public enum HTTPRequestTypesEnum {
	GET, HEAD, POST, PUT, DELETE, TRACE, OPTIONS, CONNECT, PATCH
}
